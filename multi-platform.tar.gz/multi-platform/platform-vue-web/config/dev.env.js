const BASE_API = '"http://127.0.0.1:9001"';
module.exports = {
    NODE_ENV: '"dev"',
    BASE_API: BASE_API, // 开发环境
    PROXY_URL: BASE_API // 代理地址
}
